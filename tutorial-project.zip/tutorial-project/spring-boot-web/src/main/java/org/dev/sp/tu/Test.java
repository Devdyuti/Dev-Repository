package org.dev.sp.tu;

import org.springframework.stereotype.Component;

@Component
public class Test {

	public Test() {
		System.out.println("DEFAULT CONSTRUCTOR OF TEST");
	}
}
