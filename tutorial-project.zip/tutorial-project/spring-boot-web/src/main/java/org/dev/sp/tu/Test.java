package org.dev.sp.tu;

public class Test {

	public Test() {
		System.out.println("DEFAULT CONSTRUCTOR OF TEST");
	}
}
